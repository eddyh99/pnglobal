<script>
    gsap.registerPlugin(ScrollTrigger);


    gsap.from(".banner-text-video", {
        x: "-100%",
        duration: 1,
        scrollTrigger: {
            trigger: "banner-text-video",
            start: "top 90%",
            end: "top 50%",
        }
    });

    gsap.from("#g-expansion-more", {
        x: "-100%",
        duration: 1,
        scrollTrigger: {
            trigger: "#g-expansion-more",
            start: "top 70%",
            end: "top 50%",
        }
    });

    gsap.from("#g-consulting-offshore", {
        x: "-100%",
        duration: 1,
        scrollTrigger: {
            trigger: "#g-consulting-offshore",
            start: "top 70%",
            end: "top 50%",
        }
    });

    gsap.from("#g-visa-international", {
        x: "100%",
        duration: 1,
        scrollTrigger: {
            trigger: "#g-visa-international",
            start: "top 70%",
            end: "top 50%",
        }
    });


</script>