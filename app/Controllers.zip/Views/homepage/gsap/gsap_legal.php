<script>
    gsap.registerPlugin(ScrollTrigger);
    
    gsap.from(".banner-text-video", {
        x: "-100%",
        duration: 1,
        scrollTrigger: {
            trigger: "banner-text-video",
            start: "top 90%",
            end: "top 50%",
        }
    })

    
    gsap.to("#g-legalshortdesc-title .line-animation", {
        y: 0,
        stagger: 0.5,
        duration: 0.5,
        ease: "none",
        scrollTrigger: {
            trigger: "#g-legalshortdesc-title",
            start: "top 90%",
            end: "top 50%",
        }
    })
    
    gsap.to("#g-legalshortdesc-subtitle .line-animation", {
        y: 0,
        stagger: 0.5,
        duration: 0.5,
        ease: "none",
        scrollTrigger: {
            trigger: "#g-legalshortdesc-subtitle",
            start: "top 90%",
            end: "top 50%",
        }
    })
    
    gsap.to("#g-legalshortdesc-text .line-animation", {
        y: 0,
        stagger: 0.5,
        duration: 0.5,
        ease: "none",
        scrollTrigger: {
            trigger: "#g-legalshortdesc-text",
            start: "top 90%",
            end: "top 50%",
        }
    })

    gsap.from("#g-legal-advice", {
        x: "100%",
        duration: 1,
        scrollTrigger: {
            trigger: "#g-legal-advice",
            start: "top 60%",
            end: "top 50%",
        }
    });
    
    gsap.from("#g-tax-advice", {
        x: "-100%",
        duration: 1,
        scrollTrigger: {
            trigger: "#g-tax-advice",
            start: "top 60%",
            end: "top 50%",
        }
    });
    
    gsap.from("#g-legal-vid-left", {
        x: "100%",
        duration: 1,
        scrollTrigger: {
            trigger: "#g-legal-vid-left",
            start: "top 60%",
            end: "top 50%",
        }
    });

    gsap.from("#g-legal-vid-right", {
        x: "-100%",
        duration: 1,
        scrollTrigger: {
            trigger: "#g-legal-vid-left",
            start: "top 60%",
            end: "top 50%",
        }
    });
    

</script>