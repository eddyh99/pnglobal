<script>
    gsap.registerPlugin(ScrollTrigger);

    gsap.from(".banner-text-video", {
        x: "-100%",
        duration: 1,
        scrollTrigger: {
            trigger: "banner-text-video",
            start: "top 90%",
            end: "top 50%",
        }
    })

    
    gsap.to("#g-advancetraining-title .line-animation", {
        y: 0,
        stagger: 0.5,
        duration: 0.8,
        ease: "none",
        scrollTrigger: {
            trigger: "#g-advancetraining-title",
            start: "top 90%",
            end: "top 50%",
        }
    })

    
    gsap.to("#g-advancetraining-subtitle .line-animation", {
        y: 0,
        stagger: 0.5,
        duration: 0.8,
        ease: "none",
        scrollTrigger: {
            trigger: "#g-advancetraining-subtitle",
            start: "top 90%",
            end: "top 50%",
        }
    })
    
    gsap.to("#g-advancetraining-text .line-animation", {
        y: 0,
        stagger: 0.5,
        duration: 0.8,
        ease: "none",
        scrollTrigger: {
            trigger: "#g-advancetraining-text",
            start: "top 90%",
            end: "top 50%",
        }
    })

    gsap.to("#g-advancetrainingimg .line-animation", {
        y: 0,
        stagger: 0.5,
        duration: 0.5,
        ease: "none",
        scrollTrigger: {
            trigger: "#g-advancetrainingimg",
            start: "top 90%",
            end: "top 50%",
        }
    });

    gsap.from("#g-training-course", {
        x: "100%",
        duration: 1,
        scrollTrigger: {
            trigger: "#g-training-course",
            start: "top 60%",
            end: "top 50%",
        }
    });

    gsap.from("#g-training-benefits", {
        x: "-100%",
        duration: 1,
        scrollTrigger: {
            trigger: "#g-training-benefits",
            start: "top 60%",
            end: "top 50%",
        }
    });

</script>