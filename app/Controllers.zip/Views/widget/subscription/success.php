<div class="app-content px-2 row  mb-5 pb-5">
    <div class="app-member mx-auto col-12 col-lg-8  border-1 border-white">
        <div class="subs-success">
            <div class="title-top">
                <h1 class="title">Complete</h1>
                <span class="desc">We was send an email to <?= $email?></span> <br>
            </div>
            <div class="d-flex justify-content-center mt-4">
                <img class="img-fluid" src="<?= BASE_URL?>assets/img/logo.png" alt="logo">
            </div>
            <div class="title-top d-flex flex-column justify-content-center align-items-center">
                <span class="desc text-center">Check email from SATOSHI SIGNAL,</span> <br>
                <span class="desc text-center">Click the verification link we sent and happy trading.</span>
            </div>
        </div>
    </div>
</div>