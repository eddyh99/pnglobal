<script>
    function postMessage(){
        Total.postMessage('success');
    }
    postMessage();
</script>