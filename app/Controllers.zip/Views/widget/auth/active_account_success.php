<div class="app-content px-2 row  mb-5 pb-5">
    <div class="app-member mx-auto col-12 col-lg-8  border-1 border-white">
        <div class="d-flex flex-column justify-content-center align-items-center mt-5">
            <h1 class="text-white text-center mb-2">Your Account Success for Activation</h1>
            <img src="<?= BASE_URL?>assets/img/logo.png" alt="logo">
            <h4 class="text-white text-center mt-3">Please Login Satoshi Signal App</h4>
        </div>
    </div>
</div>